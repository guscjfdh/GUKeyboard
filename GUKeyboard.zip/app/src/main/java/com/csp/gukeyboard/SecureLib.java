package com.csp.gukeyboard;

import android.app.Activity;
import android.content.Context;
import android.os.Message;
import android.security.KeyPairGeneratorSpec;
import android.telephony.TelephonyManager;

import java.io.IOException;
import java.math.BigInteger;
import java.security.InvalidAlgorithmParameterException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.SecureRandom;
import java.security.UnrecoverableEntryException;
import java.security.cert.CertificateException;
import java.security.interfaces.RSAPrivateKey;
import java.util.Calendar;

import javax.security.auth.x500.X500Principal;

/**
 * Created by leeyunho on 2015-06-18.
 */
public class SecureLib {

    KeyStore keyStore = null;
    KeyStore.PrivateKeyEntry keyEntry = null;
    RSAPrivateKey privateKey = null;
    String secretString = null;
    Activity activity = null;

    public SecureLib(Activity activity) {
        this.activity = activity;
        try {
            keyStore = KeyStore.getInstance("AndroidKeyStore");
            keyStore.load(null);
            keyEntry = (KeyStore.PrivateKeyEntry) keyStore.getEntry("key", null);
        } catch (KeyStoreException e) {
            e.printStackTrace();
        } catch (CertificateException e) {
            e.printStackTrace();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (UnrecoverableEntryException e) {
            e.printStackTrace();
        }
        if (keyEntry == null) {
            generateKey(activity);
        }
        else {
            privateKey = (RSAPrivateKey)keyEntry.getPrivateKey();
            secretString = privateKey.getModulus().toString() + getDeviceID();
        }
    }

    private void generateKey(Activity activity) {
        Context ctx = activity.getApplicationContext();
        Calendar notBefore = Calendar.getInstance();
        Calendar notAfter = Calendar.getInstance();
        notAfter.add(Calendar.YEAR, 10);
        KeyPairGeneratorSpec spec = new KeyPairGeneratorSpec.Builder(ctx)
                .setAlias("key")
                .setSubject(new X500Principal("CN=key"))
                .setSerialNumber(BigInteger.ONE).setStartDate(notBefore.getTime())
                .setEndDate(notAfter.getTime()).build();
        KeyPairGenerator keyPairGenerator = null;
        try {
            keyPairGenerator = KeyPairGenerator.getInstance("RSA", "AndroidKeyStore");
            keyPairGenerator.initialize(spec);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (NoSuchProviderException e) {
            e.printStackTrace();
        } catch (InvalidAlgorithmParameterException e) {
            e.printStackTrace();
        }
        KeyPair keyPair = keyPairGenerator.generateKeyPair();
        privateKey = (RSAPrivateKey)keyPair.getPrivate();
    }

    private String getDeviceID() {
        String deviceID = null;
        TelephonyManager telManager = (TelephonyManager)activity.getSystemService(Context.TELEPHONY_SERVICE);
        deviceID = telManager.getDeviceId();
        return deviceID;
    }

    public int getRandom(int max) {
        SecureRandom sr = null;
        try {
            sr = SecureRandom.getInstance("SHA1PRNG");
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return sr.nextInt(max);
    }

    private byte[] hash(String str) {
        MessageDigest messageDigest = null;
        try {
            messageDigest = MessageDigest.getInstance("SHA-1");
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        messageDigest.update(str.getBytes(), 0, str.length());
        return messageDigest.digest();
    }

    public int getDummyPos() {
        byte[] result = hash(secretString);
        return (result[0] & 0xff) % 8;
//        return 0;
    }

    public char getDummyVal() {
        byte[] result = hash(secretString);
        return (char)('a' + (result[1] & 0xff) % 26);
    }

}