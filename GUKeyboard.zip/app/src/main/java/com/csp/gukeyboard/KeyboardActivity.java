package com.csp.gukeyboard;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.text.Editable;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TableLayout;

public class KeyboardActivity extends ActionBarActivity implements View.OnClickListener, View.OnTouchListener {

    // ���� ���̺귯��
    SecureLib secure = null;

    final static int mKeys = 37; // �Է��� �� �ִ� ��ü Ű�� �� (1���� ����)
    int[] mResID = new int[mKeys];
    char[] mKeyChar = new char[mKeys];

    TableLayout tableLayout = null;
    ImageView[] row0IV = new ImageView[11],
            row1IV = new ImageView[11],
            row2IV = new ImageView[11],
            row3IV = new ImageView[8];
    FrameLayout popupFL = null; // ��� ǳ���� (����, �����ʵ� �߰� �ʿ�)
    ImageView popupKeyIV = null; // ǳ������ ǥ�õǴ� ImageView
    EditText userPW = null;
    ImageView key_OK = null;
//    ImageView back = null;
    int round;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_keyboard);
        popupFL = (FrameLayout)findViewById(R.id.popup); // ��� ǳ����
        popupKeyIV = (ImageView)findViewById(R.id.popup_key); // ǳ������ ǥ�õǴ� ImageView
        userPW = (EditText)findViewById(R.id.userpw);
        key_OK = (ImageView)findViewById(R.id.key_ok);
//        back = (ImageView)findViewById(R.id.key_back);
        // ���� ���̺귯�� �ʱ�ȭ
        secure = new SecureLib(this);
        // �ʱ�ȭ
        init();
        // Ű���� ���� �迭
        round = 0;
        setLayout();
        // ù��° Ű�� ����Ű�� ��� ó��
        if(round == secure.getDummyPos())
            activateLayout(false, secure.getDummyVal());
//        this.setTitle("�н����� �Է�");
//        activateLayout(false, secure.getDummyVal());
//        activateLayout(true, (char)0);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_keyboard, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    // �ʱ�ȭ
    private void init() {
        // ROW 0 : 1234567890
        //+// ����
        for (int i = 1; i < 10; i++) { // 1 ~ 9
            mResID[i] = R.drawable.key_01 + i - 1;
            mKeyChar[i] = (char)((int)'1' + i - 1);
        }
        mResID[10]   = R.drawable.key_0a;
        mKeyChar[10] = '0';
        // ROW 1 : QWERTYUIOP
        mResID[11]   = R.drawable.key_11; mKeyChar[11] = 'q';
        mResID[12]   = R.drawable.key_12; mKeyChar[12] = 'w';
        mResID[13]   = R.drawable.key_13; mKeyChar[13] = 'e';
        mResID[14]   = R.drawable.key_14; mKeyChar[14] = 'r';
        mResID[15]   = R.drawable.key_15; mKeyChar[15] = 't';
        mResID[16]   = R.drawable.key_16; mKeyChar[16] = 'y';
        mResID[17]   = R.drawable.key_17; mKeyChar[17] = 'u';
        mResID[18]   = R.drawable.key_18; mKeyChar[18] = 'i';
        mResID[19]   = R.drawable.key_19; mKeyChar[19] = 'o';
        mResID[20]   = R.drawable.key_1a; mKeyChar[20] = 'p';
        // ROW 2 : ASDFGHJKL
        mResID[21]   = R.drawable.key_21; mKeyChar[21] = 'a';
        mResID[22]   = R.drawable.key_22; mKeyChar[22] = 's';
        mResID[23]   = R.drawable.key_23; mKeyChar[23] = 'd';
        mResID[24]   = R.drawable.key_24; mKeyChar[24] = 'f';
        mResID[25]   = R.drawable.key_25; mKeyChar[25] = 'g';
        mResID[26]   = R.drawable.key_26; mKeyChar[26] = 'h';
        mResID[27]   = R.drawable.key_27; mKeyChar[27] = 'j';
        mResID[28]   = R.drawable.key_28; mKeyChar[28] = 'k';
        mResID[29]   = R.drawable.key_29; mKeyChar[29] = 'l';
        // ROW 3 : ZXCVBNM
        mResID[30]   = R.drawable.key_31; mKeyChar[30] = 'z';
        mResID[31]   = R.drawable.key_32; mKeyChar[31] = 'x';
        mResID[32]   = R.drawable.key_33; mKeyChar[32] = 'c';
        mResID[33]   = R.drawable.key_34; mKeyChar[33] = 'v';
        mResID[34]   = R.drawable.key_35; mKeyChar[34] = 'b';
        mResID[35]   = R.drawable.key_36; mKeyChar[35] = 'n';
        mResID[36]   = R.drawable.key_37; mKeyChar[36] = 'm';
    }

    // ���� ��迭
    private void setLayout() {
        int i = 0, j = 0, k1 = 0, k2 = 0;
        // ROW 0 //////////////////////////////////////////////////////////////////////
        j = 0;
        k1 = secure.getRandom(11); // blank ��ġ
        for (i = 0; i < 11; i++) {
            row0IV[i] = (ImageView) findViewById(R.id.key_01 + i);
            if (i != k1) {
                row0IV[i].setImageResource(R.drawable.key_01 + j);
                row0IV[i].setTag(R.drawable.key_01 + j++);
                row0IV[i].setClickable(true); // �̰� �־�� ACTION_UP�� ���´�.
                row0IV[i].setOnTouchListener(this);
            } else {
                row0IV[i].setImageResource(R.drawable.key_blank);
                //+// �߰�
                row0IV[i].setTag(0);
            }
        }
        // ROW 1 //////////////////////////////////////////////////////////////////////
        j = 0;
        k1 = secure.getRandom(11); // blank ��ġ
        for (i = 0; i < 11; i++) {
            row1IV[i] = (ImageView) findViewById(R.id.key_11 + i);
            if (i != k1) {
                row1IV[i].setImageResource(R.drawable.key_11 + j);
                row1IV[i].setTag(R.drawable.key_11 + j++);
                row1IV[i].setClickable(true); // �̰� �־�� ACTION_UP�� ���´�.
                row1IV[i].setOnTouchListener(this);
            } else {
                row1IV[i].setImageResource(R.drawable.key_blank);
                //+// �߰�
                row1IV[i].setTag(0);
            }
        }
        // ROW 2 //////////////////////////////////////////////////////////////////////
        j = 0;
        k1 = k2 = secure.getRandom(11); // blank ��ġ
        while (k1 == k2) // Blank�� �� ��
            k2 = secure.getRandom(11);
        for (i = 0; i < 11; i++) {
            row2IV[i] = (ImageView) findViewById(R.id.key_21 + i);
            if (i != k1 && i != k2) {
                row2IV[i].setImageResource(R.drawable.key_21 + j);
                row2IV[i].setTag(R.drawable.key_21 + j++);
                row2IV[i].setClickable(true); // �̰� �־�� ACTION_UP�� ���´�.
                row2IV[i].setOnTouchListener(this);
            } else {
                row2IV[i].setImageResource(R.drawable.key_blank);
                //+// �߰�
                row2IV[i].setTag(0);
            }
        }
        // ROW 3 //////////////////////////////////////////////////////////////////////
        j = 0;
        k1 = secure.getRandom(8); // blank ��ġ
        for (i = 0; i < 8; i++) {
            row3IV[i] = (ImageView) findViewById(R.id.key_31 + i);
            if (i != k1) {
                row3IV[i].setImageResource(R.drawable.key_31 + j);
                row3IV[i].setTag(R.drawable.key_31 + j++);
                row3IV[i].setClickable(true); // �̰� �־�� ACTION_UP�� ���´�.
                row3IV[i].setOnTouchListener(this);
            } else {
                row3IV[i].setImageResource(R.drawable.key_blank);
                //+// �߰�
                row3IV[i].setTag(0);
            }
        }
    }

    // R.drawable ID�� �̿��Ͽ� Ű(char)�� �޾ƿ���
    private char getKeyChar(int resid) {
        //+// ���� : i = 0 -> i = 1
        for (int i = 1; i < mKeys; i++)
            if (resid == mResID[i]) {
                return mKeyChar[i];
            }
        return 0;
    }

    // Ű(char)���� �̿��Ͽ� R.drawable ID�� �޾ƿ���
    private int getResID(char ch) {
        //+// ���� : i = 0 -> i = 1
        for (int i = 1; i < mKeys; i++)
            if (ch == mKeyChar[i]) {
                return mResID[i];
            }
        return 0;
    }

    //+// �߰� : ��ü Ű ��Ȱ��ȭ
    public int activateLayout(boolean enabled, char key) {
        int i = 0;
        if (enabled == false) { // ��ü Ű ��Ȱ��ȭ
            for (i = 0; i < 11; i++) {
                if (getKeyChar((int) row0IV[i].getTag()) != key) {
                    row0IV[i].setEnabled(false);
                    row0IV[i].setAlpha(0.1f);
                }
                if (getKeyChar((int) row1IV[i].getTag()) != key) {
                    row1IV[i].setEnabled(false);
                    row1IV[i].setAlpha(0.1f);
                }
                if (getKeyChar((int) row2IV[i].getTag()) != key) {
                    row2IV[i].setEnabled(false);
                    row2IV[i].setAlpha(0.1f);
                }
                if (i < 8) {
                    if (getKeyChar((int) row3IV[i].getTag()) != key) {
                        row3IV[i].setEnabled(false);
                        row3IV[i].setAlpha(0.1f);
                    }
                }
            }
        } else { // ��ü Ű Ȱ��ȭ
            for (i = 0; i < 11; i++) {
                row0IV[i].setEnabled(true);
                row0IV[i].setAlpha(1f);
                row1IV[i].setEnabled(true);
                row1IV[i].setAlpha(1f);
                row2IV[i].setEnabled(true);
                row2IV[i].setAlpha(1f);
                if (i < 8) {
                    row3IV[i].setEnabled(true);
                    row3IV[i].setAlpha(1f);
                }
            }
        }
        return 0;
    }

    ///////////////////////////////////////////
    // Ű���� �� ǥ�� �Լ�
    private void showTip(View view, boolean show) {
        if (show) {
            // ���� Ű(1) ��ǥ
            ImageView keyL = (ImageView)findViewById(R.id.key_01); // ���� �� Ű
            ImageView keyR = (ImageView)findViewById(R.id.key_0b); // ������ �� Ű
            int[] pointLeft = new int[2];
            int[] pointRight = new int[2];
            keyL.getLocationOnScreen(pointLeft);
            keyR.getLocationOnScreen(pointRight);

            // Ű�� ���� ǳ������ ���,�̹���,��ġ ���� �ʿ�
            popupKeyIV.setImageResource((int) view.getTag());
            popupFL.setVisibility(FrameLayout.VISIBLE);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)popupFL.getLayoutParams();
            int[] location = new int[2]; // x(location[0], y[location[1] ��ǥ ����
            view.getLocationOnScreen(location);
            // ���� Y ��ǥ ����
            layoutParams.topMargin = location[1] - pointLeft[1];
            // Ű�� ���� ���� X ��ǥ ����
            if (location[0] == pointLeft[0]) {
                // ���� �� Ű�� ��ġ������
                popupKeyIV.setBackgroundResource(R.drawable.popup_left);
                layoutParams.leftMargin = 10;
            }
            else if (location[0] == pointRight[0]) {
                // ������ �� Ű�� ��ġ������
                popupKeyIV.setBackgroundResource(R.drawable.popup_right);
                layoutParams.leftMargin = location[0] - 55;
            }
            else {
                popupKeyIV.setBackgroundResource(R.drawable.popup);
                layoutParams.leftMargin = location[0] - 30;
            }
            popupFL.setLayoutParams(layoutParams);
        }
        else {
            popupFL.setVisibility(FrameLayout.INVISIBLE);
        }
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        // 2015.7.28 ����Ű����� ��ġ���� �ʵ��� ó��
        if ((int)v.getTag() == 0)
            return true;

        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
//                // Ű�� ���� ǳ������ ���,�̹���,��ġ ���� �ʿ�
//                popupKeyIV.setImageResource((int) v.getTag());
//                popupFL.setVisibility(FrameLayout.VISIBLE);
//                FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)popupFL.getLayoutParams();
//                layoutParams.leftMargin = v.getLeft();
//                int bbb = v.getLeft();
//                float aaa = v.getY();
//                layoutParams.topMargin = v.getTop();
//                popupFL.setLayoutParams(layoutParams);
//                Toast.makeText(getApplicationContext(), getKeyChar((int)v.getTag()) + " DOWN", Toast.LENGTH_SHORT).show();
                showTip(v, true);
                return true;
            case MotionEvent.ACTION_UP:
//                popupFL.setVisibility(FrameLayout.INVISIBLE);
                showTip(v, false);
                //+// �߰�
                userPW.append(String.valueOf(getKeyChar((int)v.getTag())));
//                Toast.makeText(getApplicationContext(), getKeyChar((int)v.getTag()) + " UP", Toast.LENGTH_SHORT).show();
                round++;
                if(round == secure.getDummyPos())
                    activateLayout(false, secure.getDummyVal());
                else
                    activateLayout(true, (char) 0);
                return true;
        }
        return false;
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()) {
            case R.id.key_reload:
                setLayout();
                break;
            case R.id.key_back: {
//                round = userPW.getText().length();
//                if(round > 1 ) {
//                    Editable e = userPW.getText();
//                    e.delete(e.length() - 2, e.length() - 1);
//                    userPW.setText(e.toString());
//                }
//                else {
//                    Editable e = userPW.getText();
//                    e.clear();
//                    userPW.setText(e.toString());
//                }
//                return;
// 2015.7.28 ����ȣ ����
                    Editable e = userPW.getText();
                    if (e.length() > 1) {
                        round--;
                        e.delete(e.length() - 2, e.length() - 1);
                    } else {
                        e.clear();
                        round = 0;
                    }
                    userPW.setText(e.toString());
                    if (round == secure.getDummyPos())
                        activateLayout(false, secure.getDummyVal());
                    else
                        activateLayout(true, (char) 0);
                }
                break;
            case R.id.key_ok: {
                    Intent intent = new Intent();
                    Editable e = Editable.Factory.getInstance().newEditable(userPW.getText().toString());
                    e.delete(secure.getDummyPos(), secure.getDummyPos() + 1);
                    intent.putExtra("userpw", e.toString());
                    setResult(RESULT_OK, intent);
                    finish();
                }
        }
    }
}
